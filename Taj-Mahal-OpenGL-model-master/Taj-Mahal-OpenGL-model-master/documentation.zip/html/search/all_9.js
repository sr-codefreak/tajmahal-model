var searchData=
[
  ['vertices_36',['vertices',['../tree_8cpp.html#a1b55b051445f7806c79e9fb8dbc7f4de',1,'tree.cpp']]]
];
