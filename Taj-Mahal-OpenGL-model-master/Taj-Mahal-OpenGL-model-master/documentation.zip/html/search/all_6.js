var searchData=
[
  ['reshape_24',['reshape',['../main_8cpp.html#a25e760e42e42389ea3a9b5bb35596b67',1,'main.cpp']]],
  ['rotate_5fx_25',['rotate_x',['../main_8cpp.html#a39b0fab2100e4a953e64fec8663faef4',1,'main.cpp']]],
  ['rotate_5fy_26',['rotate_y',['../main_8cpp.html#aa2b2c931938813238e9d3004b7cc3e0c',1,'main.cpp']]],
  ['rotate_5fz_27',['rotate_z',['../main_8cpp.html#a664e10c19bd65bd4ceb231c09d2b1318',1,'main.cpp']]]
];
