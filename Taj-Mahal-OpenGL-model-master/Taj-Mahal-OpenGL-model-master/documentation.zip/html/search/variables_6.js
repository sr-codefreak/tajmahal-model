var searchData=
[
  ['zoom_77',['zoom',['../main_8cpp.html#a9c59ed4a7b6bdc2b1207e39fabf379a4',1,'main.cpp']]]
];
