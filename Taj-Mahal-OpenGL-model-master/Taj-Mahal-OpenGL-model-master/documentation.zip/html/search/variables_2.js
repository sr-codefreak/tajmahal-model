var searchData=
[
  ['mycolor_68',['mycolor',['../tajmahal_8cpp.html#a0e1bcec38852f76eae55d56b9e6ae221',1,'tajmahal.cpp']]],
  ['mycolors_69',['mycolors',['../main_8cpp.html#a5b91af704f4da799ef2ec0ae3550a753',1,'main.cpp']]],
  ['mycolr_70',['mycolr',['../tree_8cpp.html#a46545ed34d356e64a64e7261e73ae73e',1,'tree.cpp']]]
];
